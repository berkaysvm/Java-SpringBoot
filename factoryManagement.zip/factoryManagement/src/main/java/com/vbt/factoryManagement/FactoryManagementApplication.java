package com.vbt.factoryManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FactoryManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FactoryManagementApplication.class, args);
	}

}

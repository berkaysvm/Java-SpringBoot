package com.vbt.factoryManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactoryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
